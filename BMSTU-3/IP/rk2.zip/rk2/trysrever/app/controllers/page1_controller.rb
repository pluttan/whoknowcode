class Page1Controller < ApplicationController
    def index
    end
end