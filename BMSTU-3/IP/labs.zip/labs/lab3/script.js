function printDOM(node, indent) {
  if (node != undefined && node.tagName != "BR") {
    if (node.tagName == undefined) node.tagName = "DOCUMENT";
    console.log(" ".repeat(indent) + node.tagName);
    const outputDiv = document.getElementById("output");
    outputDiv.innerHTML += `${"&nbsp;".repeat(indent) + node.tagName} </br>`;
    for (let i = 0; i < node.children.length; i++) {
      printDOM(node.children[i], indent + 6);
    }
  }
}

window.addEventListener("load", function () {
  const body = document;
  printDOM(body, 0);
});
