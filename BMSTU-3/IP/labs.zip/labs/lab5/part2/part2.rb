class Part_2
  def initialize(a)
    a = abs(a)
    @num = 0
    to_ss(a)
    @out = even_odd()
  end

  attr_reader :out, :num

  #   def out
  #     @out
  #   end

  #   def num
  #     @num
  #   end

  private

  def abs(a)
    if a < 0
      -a
    else
      a
    end
  end

  def to_ss(decimal)
    i = 0

    while decimal > 0
      @num = (decimal % 9) * (10 ** i) + @num
      decimal = decimal / 9
      i += 1
    end

    @num
  end

  def even_odd()
    eo = [0, 0]
    @num = @num.to_s
    (0...@num.size).each do |x|
      if @num[x].to_i % 2 == 0
        eo[0] += 1
      else
        eo[1] += 1
      end
    end
    @num = @num.to_i
    eo
  end
end
