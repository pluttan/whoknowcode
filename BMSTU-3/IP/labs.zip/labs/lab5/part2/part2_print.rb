require "/Users/pluttan/Desktop/_Sem3/BMSTU-3/IP/labs/lab5/part2/part2.rb"

puts "Введите число:"
part_2 = Part_2.new(gets.chomp.to_i)
puts "Четных цифр: #{part_2.out[0]} \nНечетных цифр: #{part_2.out[1]} \nЧисло в девятиричной сс (по модулю): #{part_2.num}"
