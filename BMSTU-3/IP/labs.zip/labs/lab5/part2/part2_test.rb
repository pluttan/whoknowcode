require "/Users/pluttan/Desktop/_Sem3/BMSTU-3/IP/labs/lab5/part2/part2.rb"
require "minitest/autorun"

def count_even_odd_in_octal(decimal_number)
  octal_number = decimal_number.to_s(9)
  even_count = octal_number.count("02468")
  odd_count = octal_number.count("13579")
  [even_count, odd_count]
end

class TestPart2 < Minitest::Unit::TestCase
  def setup
    @items = Array.new(10000) { rand(20000) - 10000 }
  end

  def test_1
    i = 0
    @items.each { |x| puts Part_2.new(x).num; assert_equal(count_even_odd_in_octal(x), Part_2.new(x).out); i += 1 }
  end
end
