class Part_1
  include Math

  def y(x, z)
    return "Ошибка! х не должен быть равен нулю." if x == 0
    ((x ** 2) + (2 * (E ** x))) * cos(6 * (z / x) - 5)
  end
end
