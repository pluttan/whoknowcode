require "/Users/pluttan/Desktop/_Sem3/BMSTU-3/IP/labs/lab5/part1/part1.rb"
require "minitest/autorun"

class TestPart1 < Minitest::Unit::TestCase
  def setup
    @items = Array.new(100) { rand(200) - 100 }
    @module = Part_1.new
  end

  def test_1
    assert_nil(@items.each_slice(2) { |x| @module.y x[0], x[1] })
  end
end
