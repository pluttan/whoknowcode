require "/Users/pluttan/Desktop/_Sem3/BMSTU-3/IP/labs/lab5/part1/part1.rb"

puts "Введите x и z:\n"

x = gets.chomp
z = gets.chomp

puts Part_1.new.y x.to_i, z.to_i
