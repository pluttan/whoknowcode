class Part_3
  require "faker"

  def initialize(width = 50, auto = true)
    if auto
      @random_string = generate_random_string
    else
      input_lines = []
      puts "Введите строки (пустая строка для завершения ввода):"
      while true
        input_line = gets.chomp
        break if input_line.empty?
        input_lines << input_line
      end
      @random_string = input_lines.join(" ")
    end
    @width = width
  end

  attr_reader :random_string, :width

  def generate_random_string(min_words = 50, max_words = 100)
    num_words = rand(min_words..max_words)
    words = Faker::Lorem.words(number: num_words).join(" ")
    words.capitalize + "."
  end

  def align_string(width = @width, line = @random_string)
    words = line.split
    current_line = []
    aligned_lines = []
    len = 0

    words.each do |word|
      if (len + word.size) <= width
        current_line << word
        len += word.size + 3
      else
        aligned_lines << current_line
        current_line = [word]
        len = 0
      end
    end

    aligned_lines << current_line

    aligned_text = aligned_lines.map do |line_words|
      if line_words.size > 1
        spaces_to_add = width - line_words.join("").size
        i = 0
        while spaces_to_add > 0
          line_words[i] += " "
          spaces_to_add -= 1
          i = (i + 1) % (line_words.size - 1)
        end
      end
      line_words.join("")
    end

    aligned_text
  end
end
