require "/Users/pluttan/Desktop/_Sem3/BMSTU-3/IP/labs/lab5/part3/part3.rb"

print "Введите ширину выравнивания: "
width = gets.chomp.to_i

puts "Исходная строка:"
a = Part_3.new(width = width)
puts a.random_string

puts "Скорректированная строка:"
puts a.align_string.join("\n")
