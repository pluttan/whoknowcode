require "/Users/pluttan/Desktop/_Sem3/BMSTU-3/IP/labs/lab5/part3/part3.rb"
require "minitest/autorun"

class TestPart2 < Minitest::Unit::TestCase
  def setup
    @items = Array.new(100000) { rand(30) + 50 }
  end

  def test_1
    @items.each do |width|
      part3 = Part_3.new(width)
      aligned_lines = part3.align_string
      aligned_lines.each do |line|
        assert(((line.length > (width + 15)) == (line.length < (width - 15)) or (line.count(" ") < 1)))
      end
    end
  end
end
