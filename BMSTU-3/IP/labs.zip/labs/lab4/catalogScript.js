const cartData = [];
function addToCart(productName, productPrice) {
  cartData.push({ productName, productPrice });
  console.log("Товар успешно добавлен в корзину.");
  copyToClipboard();
  updateCartView();
}
function clearCart() {
  cartData.length = 0;
  updateCartView();
  copyToClipboard();
  console.log("Корзина очищена.");
}

function copyToClipboard() {
  const jsonString = JSON.stringify(cartData);
  const textarea = document.createElement("textarea");
  textarea.value = jsonString;
  document.body.appendChild(textarea);
  textarea.select();
  document.execCommand("copy");
  document.body.removeChild(textarea);

  console.log("Корзина скопирована в буфер обмена:", jsonString);
}
function updateCartView() {
  const cartList = document.getElementById("cart-list");
  cartList.innerHTML = "";

  if (cartData.length === 0) {
    cartList.innerHTML = "<li>Корзина пуста</li>";
  } else {
    cartData.forEach((item) => {
      const listItem = document.createElement("li");
      listItem.textContent = `${item.productName} - ${item.productPrice} руб.`;
      cartList.appendChild(listItem);
    });
  }
}
