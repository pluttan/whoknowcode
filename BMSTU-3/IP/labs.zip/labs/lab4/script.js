const selectedItems = [];

function addItem(
  productName = document.getElementById("product-name").value,
  productPrice = parseFloat(document.getElementById("product-price").value)
) {
  if (productName && !isNaN(productPrice)) {
    if (productPrice > 0) {
      selectedItems.push({ name: productName, price: productPrice });

      document.getElementById("product-name").value = "";
      document.getElementById("product-price").value = "";

      displayOrder();
    } else {
      alert("Значение поля стоимость не может быть меньше или равно нулю");
    }
  } else {
    alert("Пустое значение поля!");
  }
}

function displayOrder() {
  const tableBody = document.querySelector("#order-table tbody");
  tableBody.innerHTML = "";

  for (const item of selectedItems) {
    const row = document.createElement("tr");
    row.innerHTML = `<td>${
      item.name
    }</td><td class = "price">${item.price.toFixed(2)}</td>`;
    tableBody.appendChild(row);
  }
}

function calculateTotal() {
  const total = selectedItems.reduce((sum, item) => sum + item.price, 0);
  alert(`Общая стоимость заказа: ${total.toFixed(2)}`);
}

document.addEventListener("mouseover", function (event) {
  if (event.target.tagName === "TD" && event.target.classList[0] === "price") {
    console.log(1);
    event.target.style.backgroundColor = "lightblue";
  }
});

document.addEventListener("mouseout", function (event) {
  if (event.target.tagName === "TD" && event.target.classList[0] === "price") {
    event.target.style.backgroundColor = "white";
  }
});

function importCart() {
  navigator.clipboard
    .readText()
    .then((text) => {
      try {
        const cartData = JSON.parse(text);
        cartData.forEach((item) => {
          addItem(item.productName, item.productPrice);
        });
      } catch (error) {
        console.error("Ошибка при импорте корзины:", error);
      }
    })
    .catch((error) => {
      console.error("Ошибка при чтении буфера обмена:", error);
    });
}
