class Page2Controller < ApplicationController
  def result
    @n = 0
    params.each do |key, value|
      Rails.logger.warn "Param #{key}: #{value}"
      if key == "inputText" then @n = value.to_i end
    end
    @message = find_and_check_for_range(@n)
    @result = @message[1]
    @message = @message[0]
    @result
  end

  def find_divisors_and_check(number, n)
    divisors = (1..(number / 2 + 1)).select { |divisor| number % divisor == 0 }
    sum_of_divisors = divisors.sum
    second_divisors = (1..(sum_of_divisors / 2 + 1)).select { |divisor| sum_of_divisors % divisor == 0 }
    if second_divisors.sum == number && number < sum_of_divisors && n >= sum_of_divisors
      return [number, sum_of_divisors]
    else
      return false
    end
  end

  def find_and_check_for_range(n)
    id = 0
    @message = ""
    @result = []
    (1..n).each do |number|
      result = find_divisors_and_check(number, n)
      id += 1 if result
      @result << result if result
      @message += "<tr><td>#{id}</td> <td>#{result[0]}</td> <td>#{result[1]}</td></tr>" if result
    end
    [@message.html_safe, @result]
  end
end
