require "/Users/pluttan/Desktop/_Sem3/BMSTU-3/IP/labs/lab8/trysrever/test/test_helper.rb"

class TwinsControllerTest < ActionDispatch::IntegrationTest
  test "should get input" do
    get root_url
    assert_response :success
  end

  test "should get view" do
    get result_url
    assert_response :success
  end

  test "get inputText = 10000" do
    get result_url, params: { inputText: 10000 }
    puts assigns[:result]
    target = [[220, 284],
              [1184, 1210],
              [2620, 2924],
              [5020, 5564],
              [6232, 6368]]

    assert_equal assigns[:result], target
  end

  test "get inputText = 1000" do
    get result_url, params: { inputText: 1000 }
    puts assigns[:result]
    target = [[220, 284]]

    assert_equal assigns[:result], target
  end
end
