require "test_helper"

class TestJobTest < ActiveJob::TestCase
  # test "the truth" do
  #   assert true
  # end
end
